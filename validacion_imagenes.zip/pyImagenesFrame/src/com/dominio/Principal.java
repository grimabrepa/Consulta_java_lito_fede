
package com.dominio;

import com.dominio.gui.Gui;

/**
 *
 * @author Marcelo
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Gui ventana = new Gui();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        
    }
    
}
